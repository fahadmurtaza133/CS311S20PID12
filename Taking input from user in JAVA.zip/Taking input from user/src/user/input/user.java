package user.input;

import java.util.Scanner;

public class user {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
// Taking input from user in java
		
  // taking a string
		 Scanner myObj = new Scanner(System.in);
		 System.out.println(" Enter the String you want to Print");
		 String a = myObj.nextLine();
		 System.out.println(" Your Name is "+ a);
  // Taking int,float,long,short
		 System.out.println("Enter any integer ");
		 int b = myObj.nextInt();
		 System.out.println("Enter any float number ");
		 float c = myObj.nextFloat();
		 System.out.println("Enter any long number ");
		 double d = myObj.nextLong();
		 
		 System.out.println("Your integer is  "+ b + "Your float is"+ c+ " Your long number is "+ d);
		 
		 
	}

}
